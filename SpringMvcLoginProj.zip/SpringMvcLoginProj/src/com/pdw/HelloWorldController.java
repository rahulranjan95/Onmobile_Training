package com.pdw;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import org.springframework.stereotype.Controller;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.servlet.ModelAndView;  
  
@Controller //user defined controller
//@RequestMapping("")
public class HelloWorldController {  
      
    @RequestMapping("/hello")  //@getmapping,putmapping,deletemappingn,postmapping
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) {  
        String name=request.getParameter("name");  
        String password=request.getParameter("password");  
          //System.out.println(password);
        //jdbc 5 steps
        if(password.equals("admin")){  
        String message = "HELLO "+name;  //model
        return new ModelAndView("hellopage", "mes", message);  //jsp=servlet+html 
        }  
        else{  
            return new ModelAndView("errorpage", "message","Sorry, username or password error");  
        }  
    }  
 
}  